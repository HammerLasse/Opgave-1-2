using Opgave_1___Class_Library_og_Unit_Test;

namespace TrophyTest

{
    [TestClass]
    public class TrophyTest
    {
        private Trophy trophy = new Trophy { Id = 1, Competition = "Football", Year = 2021 };
        private Trophy trophyNull = new Trophy { Id = 1, Competition = null, Year = 2021 };
        private Trophy trophyShort = new Trophy { Id = 1, Competition = "Fo", Year = 2021 };
        private Trophy trophyAccepted = new Trophy { Id = 1, Competition = "123", Year = 2021 };
        private Trophy trophyYear1969 = new Trophy { Id = 1, Competition = "Football", Year = 1969 };
        private Trophy trophyYear1970 = new Trophy { Id = 1, Competition = "Football", Year = 1970 };
        private Trophy trophyYear1971 = new Trophy { Id = 1, Competition = "Football", Year = 1971 };
        private Trophy trophyYear2023 = new Trophy { Id = 1, Competition = "Football", Year = 2023 };
        private Trophy trophyYear2024 = new Trophy { Id = 1, Competition = "Football", Year = 2024 };
        private Trophy trophyYear2025 = new Trophy { Id = 1, Competition = "Football", Year = 2025 };




        [TestMethod]
        public void ToStringTest()
        {
            string str = trophy.ToString();
            Assert.AreEqual("Id: 1, Competition: Football, Year: 2021", str);
        }

        [TestMethod]
        public void competitionCantBeNullTest()
        {
            // Act
            trophy.competitionCantBeNull();
            Assert.ThrowsException<ArgumentNullException>(() => trophyNull.competitionCantBeNull());

        }

        [TestMethod]
        public void competitionAccepted()
        {
            trophyAccepted.competitionCantBeShort(); //Burde accepteres
            trophyAccepted.competitionCantBeNull(); //Burde accepteres

        }



        [TestMethod]
        public void competitionTooShortTest()
        {

            trophy.competitionCantBeShort();
            Assert.ThrowsException<ArgumentException>(() => trophyShort.competitionCantBeShort());

        }

        [TestMethod]
        public void validateYearBelowTest()
        {
            trophy.validateYear();
            Assert.ThrowsException<ArgumentOutOfRangeException>(() => trophyYear1969.validateYear());
        }

        [TestMethod]
        public void validateYearAboveTest()
        {
            trophy.validateYear();
            Assert.ThrowsException<ArgumentOutOfRangeException>(() => trophyYear2025.validateYear());
        }

        [TestMethod]
        public void validateYearBoundaryTest()
        {

            trophyYear2023.validateYear(); //Burde accepteres
            trophyYear2024.validateYear(); //Burde accepteres
            trophyYear1970.validateYear(); //Burde accepteres
            trophyYear1971.validateYear(); //Burde accepteres
        }

    }
}