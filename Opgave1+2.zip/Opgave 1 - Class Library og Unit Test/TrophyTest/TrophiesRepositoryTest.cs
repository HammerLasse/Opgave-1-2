﻿using Opgave_1___Class_Library_og_Unit_Test;

namespace TrophyTest
{
    [TestClass]
    public class TrophiesRepositoryTest
    {
        private TrophiesRepository _trophies;



        [TestInitialize]
        public void Setup()
        {
            _trophies = new TrophiesRepository();
        }

        [TestMethod]
        public void GetAllTest()
        {
            List<Trophy> trophies = _trophies.GetAll();

            Assert.AreEqual(5, trophies.Count);
            Assert.AreEqual("Running 2020", trophies[0].Competition);
            Assert.AreEqual("Running 2024", trophies[4].Competition);

        }

        [TestMethod]
        public void GetByIdTest()
        {
            Trophy? trophy = _trophies.GetById(1);

            Assert.IsNotNull(trophy);
            Assert.AreEqual(1, trophy.Id);
            Assert.AreEqual("Running 2020", trophy.Competition);

        }

        [TestMethod]
        public void GetByIdFailTest()
        {
            Trophy? trophy = _trophies.GetById(100);
            Assert.IsNull(trophy);
        }

        [TestMethod]
        public void GetByIdNullTest()
        {
            Trophy? trophy = _trophies.GetById(null);
            Assert.IsNull(trophy);
        }

        [TestMethod]
        public void AddTest()
        {
            Trophy Trophy = new Trophy { Competition = "Running 2010", Year = 2010 };

            Assert.AreEqual(6, _trophies.Add(Trophy).Id);
            Assert.AreEqual(6, _trophies.GetAll().Count);

        }

        public void AddTestFail()
        {
            Trophy trophy = new Trophy { Competition = "Running 2025", Year = 2025 }; //Year is above 2024

            _trophies.Add(trophy);

        }
    }
}
