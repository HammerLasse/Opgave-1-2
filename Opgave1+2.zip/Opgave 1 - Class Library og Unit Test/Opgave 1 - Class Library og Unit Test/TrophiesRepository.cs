﻿namespace Opgave_1___Class_Library_og_Unit_Test
{
    public class TrophiesRepository
    {
        private List<Trophy> trophies = new List<Trophy>();
        private int nextId = 1;

        public TrophiesRepository()
        {
            trophies.Add(new Trophy { Id = nextId++, Competition = "Running 2020", Year = 2020 });
            trophies.Add(new Trophy { Id = nextId++, Competition = "Running 2021", Year = 2021 });
            trophies.Add(new Trophy { Id = nextId++, Competition = "Running 2022", Year = 2022 });
            trophies.Add(new Trophy { Id = nextId++, Competition = "Running 2023", Year = 2023 });
            trophies.Add(new Trophy { Id = nextId++, Competition = "Running 2024", Year = 2024 });

        }

        public List<Trophy> GetAll()
        {
            List<Trophy> copyTrophies = new List<Trophy>();

            foreach (Trophy trophy in trophies)
            {
                copyTrophies.Add(new Trophy(trophy));
            }

            return copyTrophies;
        }

        public Trophy? GetById(int? id)
        {
            if (id == null)
            {
                return null;
            }

            return trophies.Find(trophy => trophy.Id == id.Value);

        }

        public Trophy Add(Trophy trophy)
        {
            trophy.validate();
            trophy.Id = nextId++;
            trophies.Add(trophy);
            return trophy;

        }

        public Trophy? Remove(int id)
        {
            Trophy? trophy = GetById(id);
            if (trophy == null)
            {
                return null;
            }

            trophies.Remove(trophy);
            return trophy;
        }

        public Trophy? UpdateId(int id, Trophy newTrophy)
        {
            newTrophy.validate();
            Trophy? existingTrophy = GetById(id);
            if (existingTrophy == null)
            {
                return null;
            }
            existingTrophy.Competition = newTrophy.Competition;
            existingTrophy.Year = newTrophy.Year;
            return existingTrophy;
        }




        public IEnumerable<Trophy> Get(int? yearAfter = null, string? competitionIncludes = null, string? orderby = null)
        {
            IEnumerable<Trophy> result = new List<Trophy>(trophies);

            if (yearAfter != null)
            {
                result = result.Where(trophy => trophy.Year > yearAfter);
            }
            if (competitionIncludes != null)
            {
                result = result.Where(trophy => trophy.Competition.Contains(competitionIncludes));
            }

            if (orderby != null)
            {
                orderby = orderby.ToLower();
                switch (orderby)
                {
                    case "year":
                    case "year_asc":
                        result = result.OrderBy(trophy => trophy.Year);
                        break;
                    case "year_desc":
                        result = result.OrderByDescending(trophy => trophy.Year);
                        break;
                    case "competition":
                    case "competition_asc":
                        result = result.OrderBy(trophy => trophy.Competition);
                        break;
                    case "competition_desc":
                        result = result.OrderByDescending(trophy => trophy.Competition);
                        break;
                    default:
                        throw new ArgumentException("Invalid order by value");
                }
            }
            return result;
        }






    }
}
