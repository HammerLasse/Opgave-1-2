﻿namespace Opgave_1___Class_Library_og_Unit_Test
{
    public class Trophy
    {
        public int Id { get; set; }
        public string Competition { get; set; }
        public int Year { get; set; }

        public Trophy(int id, string competition, int year)
        {

            Id = id;
            Competition = competition;
            Year = year;
        }

        public Trophy()
        {

        }

        public Trophy(Trophy other)
        {
            Id = other.Id;
            Competition = other.Competition;
            Year = other.Year;

        }




        public override string ToString()
        {
            return $"Id: {Id}, Competition: {Competition}, Year: {Year}";
        }

        public void validateYear()
        {
            if (Year < 1970 || Year > 2024)
            {
                throw new ArgumentOutOfRangeException("Year must be between or equal to 1970 and 2024");
            }
        }

        public void competitionCantBeNull()
        {
            if (Competition == null)
            {

                throw new ArgumentNullException("Competition cannot be null");

            }

        }

        public void competitionCantBeShort()
        {
            if (Competition.Length < 3)
            {
                throw new ArgumentException("Competition must be at least 3 characters long");
            }
        }

        public void validate()
        {
            competitionCantBeNull();
            competitionCantBeShort();
            validateYear();
        }








    }


}
